export function getData() {
    return (
        [
            {
                title: "Malibu",
                price: "25000",
                color: "black",
                Image: "https://www.autolist.com/6tuem73u73an/35YrjQSF1OhDZDC43cDNsS/e38379ea1b499d9c0caa6273987d1b71/2020-chevrolet-malibu-styling-image.jpg",
                id: 1
            },
            {
                title: "Onix",
                price: "15000",
                color: "white",
                Image: "https://kapital.uz/wp-content/uploads/2023/05/kptl-2-2.png",
                id: 2
            },
            {
                title: "Gentra",
                price: "14000",
                color: "grey",
                Image: "https://repost.uz//storage/uploads/24464992-1642658506-mursyaev-post-material.png",
                id: 3
            },
            {
                title: "Cobalt",
                price: "13000",
                color: "blue",
                Image: "https://www.ixbt.com/img/n1/news/2023/4/5/2020-Chevrolet-Cobalt-LT-Brazil-exterior-01-720x300.png",
                id: 4
            },
            {
                title: "Nexia 3",
                price: "12000",
                color: "black",
                Image: "https://avatars.mds.yandex.net/get-verba/997355/2a000001868a3499e47382a4b9385588387a/cattouch",
                id: 5
            },
            {
                title: "Spark",
                price: "10000",
                color: "red",
                Image: "https://i.pinimg.com/originals/02/72/eb/0272eba474cc44a0bd27008cfe4fddb5.png",
                id: 6
            },
        ]
    )
}